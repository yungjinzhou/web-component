<template>
    <div class="container" id="container">

    <div class="container-fluid">
        <table class="table table-hover">           

        <tbody>
            <tr><th>序号</th><th>股票代码</th><th>股票简称</th><th>涨跌幅</th><th>换手率</th><th>最新价(元)</th><th>前期高点</th><th>前期高点日期</th><th>添加自选</th></tr>
            
            <tr v-for="item in dataList">
                <td>{{item.id}}</td>
                <td>{{item.code}}</td>
                <td>{{item.sname}}</td>
                <td>{{item.rate01}}</td>
                <td>{{item.rate02}}</td>
                <td>{{item.new_prize}}</td>
                <td>{{item.high}}</td>
                <td>{{item.date}}</td>
                <td><input @click="fnAdd(item.code)" type="button" value="添加" name="toAdd"></td>

            </tr>
          
        
         </tbody>

   </table>
    </div>
</div>
</template>

<script>
export default {
  name:'homelist',
  data: function () {
      return {
          dataList:[]
      }
  },
  mounted:function () {
    //   1.发送 所有股票的请求   8080 跨 7890
    this.axios({
        url:'/index_data',
        method:'get'
    })
    .then(response => {
        // console.log(response)
        this.dataList = response.data;
    })
  },
  methods:{
      fnAdd:function (addCode){
        //   2.发送 是否关注的 请求
        this.axios({
            url:'/add_data',
            method:'get',
            params:{
                code:addCode
            }
        })
        .then(response=>{
            // console.log(response)
            alert(response.data)
        })
      }
  }
}
</script>

