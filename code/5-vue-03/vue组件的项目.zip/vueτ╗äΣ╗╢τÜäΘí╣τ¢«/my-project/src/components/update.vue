<template>
  <div class="container">
    <div class="container-fluid">
      <div class="input-group">
          <span class="input-group-addon">正在修改：</span>
          <span class="input-group-addon" id="codeshow">{{code}}</span>
          <input id="note_info" type="text" class="form-control" v-model="content">
          <span @click="fnModify" id="update" class="input-group-addon" style="cursor: pointer">修改</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name:'update',
  data: function () {
      return {
          code:110,
          content:'跟着党的感觉走, 一夜暴富不是梦!'
      }
  },
  mounted: function () {
    //   接收显示 个人中心 传过来的数据
    this.code = this.$route.params.code;
    this.content = this.$route.params.content;
  },
  methods:{
      fnModify:function(){
        //  5.发送 修改 备注的请求
        this.axios({
            url:'/change_data',
            method:'get',
            params:{
                code:this.code,
                info:this.content
            }
        })
        .then(response=>{
            // 1.谈提示
            alert(response.data)
            // 2.跳转到 个人中心
            this.$router.push('/center')
        })
      }
  }
}
</script>

