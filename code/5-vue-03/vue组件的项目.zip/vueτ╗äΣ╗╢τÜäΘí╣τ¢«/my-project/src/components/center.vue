<template>
  <div class="container">

    <div class="container-fluid">
        <table class="table table-hover">
            
            <tbody>
            <tr><th>股票代码</th><th>股票简称</th><th>涨跌幅</th><th>换手率</th><th>最新价(元)</th><th>前期高点</th><th>备注信息</th><th>修改备注</th><th>del</th></tr>
            
            <tr v-for="item in dataList">
                <td>{{item.code}}</td>
                <td>{{item.sname}}</td>
                <td>{{item.rate01}}</td>
                <td>{{item.rate02}}</td>
                <td>{{item.new_prize}}</td>
                <td>{{item.high}}</td>
                <td>{{item.bak}}</td>
                 <td>
                     <!-- 在vue的工具中 需要使用 路由标签 -->
                     <!-- <router-link to='/update' class="btn btn-default btn-xs router-link-active" type="button"> -->
                    <router-link :to="{name:'update',params:{code:item.code,content:item.bak}}" class="btn btn-default btn-xs router-link-active" type="button">
                       
                        <span aria-hidden="true" class="glyphicon glyphicon-star"></span> 修改
                     </router-link>
  

                 </td>
                 <td>
                     <input @click="fnDel(item.code)" type="button" value="删除" name="toDel">
                </td>
    
            </tr>
         
           </tbody>
        </table>
    </div>
</div>
</template>

<script>
export default {
  name:'center',
  data:function () {
      return {
          dataList:[]
      }
  },
  mounted: function () {
      
    //   3.发送  个人中心的请求
    this.axios({
        url:'/center_data',
        method:'get'
    })
    .then(response=>{
        console.log(response.data)
        this.dataList = response.data
    })
  },
  methods: {
      fnDel:function(delCode){
        //  4.发送删除请求
            this.axios({
            url:'/del_data',
            method:'get',
            params:{
                code:delCode
            }
        })
        .then(response=>{
            // 1.谈提示
            alert(response.data)

            // 2.刷新当前的页面 center
            this.$router.go('/center')
        })

      }
  }
}
</script>

