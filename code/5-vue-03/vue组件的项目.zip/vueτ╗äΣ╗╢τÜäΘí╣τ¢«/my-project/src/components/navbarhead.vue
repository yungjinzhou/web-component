<template>
    <div class="navbar navbar-inverse navbar-static-top ">
        <div class="container">
        <div class="navbar-header">
                <button class="navbar-toggle" data-toggle="collapse" data-target="#mymenu">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                 </button>
                 <a href="#" class="navbar-brand">选股系统</a>
        </div>
        <div class="collapse navbar-collapse" id="mymenu">
                <ul class="nav navbar-nav">
                        <li @click="isShow = 0" :class="(isShow == 0)?'active':''"><router-link to="/">股票信息</router-link></li>
                        <li @click="isShow = 1" :class="(isShow == 1)?'active':''"><router-link to="/center">个人中心</router-link></li>
                </ul>
        </div>
        </div>
</div>
</template>

<script>
export default {
  name:'navbarhead',
  data: function () {
          return {
                  isShow :0
          }
  }
}
</script>

