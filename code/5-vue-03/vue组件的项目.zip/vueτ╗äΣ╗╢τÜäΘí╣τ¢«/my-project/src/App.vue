<template>
  <div id="app">
    <!-- <img src="./assets/logo.png"> -->
    <!-- 3.使用 导航条的组件 -->
    <navbarhead></navbarhead>
    <router-view/>
  </div>
</template>

<script>
// 1.导入 导航条
import navbarhead from '@/components/navbarhead'
export default {
  name: 'App',
  // 2.注册
  components:{
    navbarhead
  }
}
</script>


