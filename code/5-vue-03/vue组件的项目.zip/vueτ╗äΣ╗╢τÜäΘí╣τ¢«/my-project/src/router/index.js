import Vue from 'vue'
import Router from 'vue-router'
// import navbarhead from '@/components/navbarhead'
import homelist from '@/components/homelist'
import center from '@/components/center'
import update from '@/components/update'


Vue.use(Router)

export default new Router({
  routes: [
    // {
    //   path: '/',
    //   name: 'navbarhead',
    //   component: navbarhead
    // }

    {
      path: '/',
      name: 'homelist',
      component: homelist
    },
    {
      path: '/center',
      name: 'center',
      component: center
    },
    {
      path: '/update',
      name: 'update',
      component: update
    }
  ]
})
